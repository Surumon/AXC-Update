
sub EVENT_SAY {
 if($text =~ /Hail/i) {
	quest::say("Well hello thar! It's good to see ya again, what can I do fer ye?");
 }
}

sub EVENT_ITEM {
  #do all other handins first with plugin, then let it do disciplines
  plugin::try_tome_handins(\%itemcount, $class, 'Berserker');
  plugin::return_items(\%itemcount);
}


