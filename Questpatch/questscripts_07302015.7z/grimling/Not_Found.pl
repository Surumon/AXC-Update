sub EVENT_SAY{
if($text=~/Hail/i){
quest::say("Well met, friend.  May I be of assistance?"); }
}
#END of FILE Zone:grimling  ID:Not_Found -- Sergeant_Cursah 

sub EVENT_SAY{
if($text=~/Hail/i){
quest::say("Well met, friend.  May I be of assistance?"); }
}
#END of FILE Zone:grimling  ID:Not_Found -- Captain_Darznel 

sub EVENT_SAY{
if($text=~/Hail/i){
quest::say("Well met, friend.  May I be of assistance?"); }
}
#END of FILE Zone:grimling  ID:Not_Found -- Sergeant_Tidwah 

