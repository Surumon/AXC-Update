sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Good day, $name. If you're interested in serving the war effort you can begin by speaking with one of the scouts here in the outpost. If you'll excuse me, I must return to making plans."); }
}
#END of FILE Zone:grimling  ID:167125 -- Veteran_Vadrel 

