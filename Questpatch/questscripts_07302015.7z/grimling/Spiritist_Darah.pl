sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello, $name, welcome to the war zone. I probably don't have to mention that these are dangerous times here. I pray to the spirits that they might reveal to me the path to victory over our enemy. Recently, I have begun to feel that the answer to my pleas will present itself in the near future."); }
}
#END of FILE Zone:grimling  ID:167130 -- Spiritist_Darah 

