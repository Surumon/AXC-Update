#Arcanist_Ukigit

sub EVENT_DEATH {
  quest::say("You will die...");
 } 