sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Well met, friend. May I be of assistance?");
  }
}
#END of FILE Zone:grimling  ID:Not_Found -- Captain_Darznel