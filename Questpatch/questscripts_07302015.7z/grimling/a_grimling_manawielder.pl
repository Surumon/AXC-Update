#a_grimling_manawielder

sub EVENT_DEATH {
  quest::signalwith(167663,1,0);
} 