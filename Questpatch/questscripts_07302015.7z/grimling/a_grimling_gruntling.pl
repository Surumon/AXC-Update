#a_grimling_gruntling

sub EVENT_DEATH {
  quest::signalwith(167663,1,0);
} 