#a_grimling_painsoother

sub EVENT_DEATH {
  quest::signalwith(167663,1,0);
} 