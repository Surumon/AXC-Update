# NPC: Tutorial rats
# Angelox

sub EVENT_COMBAT{
    quest::emote("flies forward, gnashing its teeth");
}

sub EVENT_DEATH{
  quest::emote("'s corpse flutters to the ground");
 }

# EOF zone: Tutorialb