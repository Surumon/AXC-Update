# NPC: Tutorial spiders
# Angelox

sub EVENT_COMBAT{
    quest::emote("scuttles forward to attack.");
}

sub EVENT_DEATH{
  quest::emote("collapses in a heap of broken legs.");
 }

# EOF zone: Tutorialb