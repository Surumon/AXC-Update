# NPC: #Queen_Gloomfang
# Angelox

sub EVENT_COMBAT{
   quest::emote("brandishes razor sharp fangs and attacks!");
}

sub EVENT_DEATH{
  quest::emote("'s corpse unleashes a chittering keen as it falls backward.");
 }

# EOF zone: Tutorialb