# NPC: Droga Mobs
# Angelox

sub EVENT_COMBAT{
 quest::say("The time has come for you to taste the might of my magic");
}

sub EVENT_DEATH{
 quest::emote("'s corpse tries to mumble one last spell before falling over dead.");
 }

# Droga Mobs
