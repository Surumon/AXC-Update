# NPC: Droga Mobs
# Angelox

sub EVENT_COMBAT{
    quest::say("Attacking your aggressor Master.");
}
# Droga Mobs
