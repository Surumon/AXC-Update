# NPC: Droga Mobs
# Angelox

sub EVENT_COMBAT{
    quest::emote("quickly skitters towards its prey.");
}

sub EVENT_DEATH{
  quest::emote("'s corpse explodes in a large spray of ichor as it is squashed for good..");
 }

# Droga Mobs
