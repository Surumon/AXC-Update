sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Good day t'ye. $name!  'Tis sure good t'see ye here.  I've been doin' a bit of thinkin' about the past.  Ah yes. me past t'would surprise even ye.  Alas. I cannae dwell on it now.  I am Barrith the Brave.  I must be searchin' for a hero worthy of havin' the eyes of the gods upon them."); }
}
#END of FILE Zone:kaladima  ID:60043 -- Barrith_the_Brave 

