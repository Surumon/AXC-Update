sub EVENT_DEATH {
  quest::emote("Your efforts are most brave. The realm of spirits is in constant danger these days. Mortals are tampering with the balance more and more often. Learn from these battles and make note of the importance of balance. The task that you complete this day may mock you in the days to come if you do not heed its lesson. Take care, my friend.");
}