sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I am sorry friend but my duties prevent me from conversing. There are others that will gladly greet you and introduce you to the customs of our society."); }
}
#END of FILE Zone:stonebrunt  ID:100019 -- a_kejekan_mujahed 

