sub EVENT_SIGNAL {
{ quest::depop(); }
}

# End of File  Zone: PoFire  ID: 217081  -- Warlord_Prollaz