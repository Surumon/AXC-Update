


sub EVENT_SIGNAL {
{ quest::depop; }
}

# End of File  Zone: PoFire  ID: 217077  -- Azobian_the_Darklord