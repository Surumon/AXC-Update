# one of ten shissar to be killed to start the cursed cycle
#

sub EVENT_DEATH {
  quest::signalwith(162255,162023,0);
}


# EOF zone: ssratemple ID: 162023 NPC: Warden_Mekuzh

