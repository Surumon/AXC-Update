# one of ten shissar to be killed to start the cursed cycle
#

sub EVENT_DEATH {
  quest::signalwith(162255,162089,0);
}


# EOF zone: ssratemple ID: 162089 NPC: #Rhozth_Ssravizh

