# one of ten shissar to be killed to start the cursed cycle
#

sub EVENT_DEATH {
  quest::signalwith(162255,162011,0);
}


# EOF zone: ssratemple ID: 162011 NPC: Taskmaster_Zerumaz

