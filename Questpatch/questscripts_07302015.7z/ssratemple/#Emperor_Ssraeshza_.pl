# spawn shissar wraiths on death of emperor ssraeshza for celestial rifts
#

sub EVENT_DEATH {
  quest::spawn2(162210,0,0,953,-332,403.1,190);
  quest::spawn2(162210,0,0,953,-324,403.1,190);
  quest::spawn2(162210,0,0,953,-316,403.1,190);
  quest::spawn2(162210,0,0,937,-332,403.1,190);
  quest::spawn2(162210,0,0,937,-324,403.1,190);
  quest::spawn2(162210,0,0,937,-316,403.1,190);
}

# EOF zone: ssartemple ID: 162227 NPC: #Emperor_Ssraeshza_

