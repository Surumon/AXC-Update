# beginning of the arch lich rhag`zadune cycle
#

sub EVENT_DEATH {
  quest::spawn2(162192,0,0,634.3,-280.5,147.6,191.6); # spawn rhag`mozdezh
}

# EOF zone: ssratemple ID: 162178 NPC: #Rhag`Zhezum

