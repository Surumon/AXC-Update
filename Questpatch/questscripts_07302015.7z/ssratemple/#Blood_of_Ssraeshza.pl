# Emperor Ssraeshza trigger
#

sub EVENT_DEATH {
  quest::signalwith(162065,99,0);
}

#EOF zone: ssratemple ID: 162189 NPC: #Blood_of_Ssraeshza

