sub EVENT_SAY { 
if($text=~/70 percent/i){
quest::say("spits black blood on your armor and slithers toward you."); }
}
#END of FILE Zone:ssratemple  ID:162025 -- A_Shissar_Disciple 

