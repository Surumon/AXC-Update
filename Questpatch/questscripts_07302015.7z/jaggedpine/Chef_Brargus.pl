sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Whatchoo want?"); }
}
#END of FILE Zone:jaggedpine  ID:181119 -- Chef_Brargus 

