sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Just cuz we live in da swamp don't mean youse gotta stay in da dark. Da Swamp News got all da news. And it ain't go no big wurds in it like da other news'es out dair."); }
}
#END of FILE Zone:feerrott  ID:49071 -- Klob_Pulp 

