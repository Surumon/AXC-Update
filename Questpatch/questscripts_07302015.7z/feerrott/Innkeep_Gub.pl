sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Huh? Oh hi $name. Youse want to buy sumthin?"); }
}
#END of FILE Zone:feerrott  ID:47144 -- Innkeep_Gub 

