# Shaman Epic 1.0
# Capt Surestout
# Ocean of Tears
# Aramid September 2006

sub EVENT_DEATH {
  if ($class == "Shaman") {
  quest::say("You have run me through! Beware the Pirates of Gunthak.. They will avenge me.. Unngh!!");
  quest::spawn2(69149,0,0,-5386.8,783.0,12.9,165.8);
 }
}


# End of File - NPCID 69100 - Capt_Surestout

