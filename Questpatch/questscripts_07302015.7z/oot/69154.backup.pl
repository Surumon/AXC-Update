## INVISIBLE ONE!!
## SirensBane travels from oot to oot to freporte and back
## Angelox
## Qadar
sub EVENT_SIGNAL{
   if($debugpl){quest::shout("Fake boat depopping!");}
  quest::depop();
}
