sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Please seek guidance from the clerics within this temple.  I am but a Sentry of Passion and my duty is to protect this temple."); }
}
#END of FILE Zone:freportn  ID:8052 -- Sentry_Boris 

