sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to the Hall of Truth!  May the will of Mithaniel Marr guide you through life.  We are glad to see that you have an interest in our ways.  Please speak with any of my priests or knights and they shall help you find your faith."); }
}
#END of FILE Zone:freportn  ID:8045 -- Eestyana_Naestra 

