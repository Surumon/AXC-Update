sub EVENT_ITEM { 
if($itemcount{13872} == 1){
quest::givecash("14","0","0","0");
quest::faction("322","1");
quest::faction("304","-1");
quest::faction("Not_Found","-1");
quest::faction("Not_Found","1");
quest::faction("10103","1"); }
}
#END of FILE Zone:freportn  ID:8034 -- Celsar_Vestagon 

