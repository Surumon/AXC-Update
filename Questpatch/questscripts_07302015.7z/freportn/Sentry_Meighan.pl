sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Please speak no further.  I am nothing more than a defender of this temple.  The words of Marr lie with the masters and clerics of this temple.  They await you."); }
}
#END of FILE Zone:freportn  ID:8049 -- Sentry_Meighan 

