sub EVENT_ITEM { 
if($itemcount{13894} == 1){
quest::say("Aye.. You cut out the middleman..  I shall reward you.. hmm..  I have not found anything. how about..  <CRACK!! SNAP!! RIPP!!>  How about something off meself?");
quest::say("Aye.. You cut out the middleman..  I shall reward you.. hmm..  I have not found anything. how about..  <CRACK!! SNAP!! RIPP!!>  How about something off meself?");
quest::summonitem("13074","1"); }
}
#END of FILE Zone:tox  ID:78028 -- a_skeleton 

