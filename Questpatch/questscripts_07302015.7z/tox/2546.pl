sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Haha!! Another victory for our lord Cazic-Thule!  May your corpse be a dread-inspiring sign to those who travel this forest!"); }
}
#END of FILE Zone:tox  ID:2546 -- a_heretic_prophet 

