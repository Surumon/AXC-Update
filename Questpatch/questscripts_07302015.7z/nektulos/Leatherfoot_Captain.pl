sub EVENT_DEATH {
	quest::say("My comrades will avenge my death.");
}