sub EVENT_ITEM{
if($itemcount{1673} == 1){
quest::faction("Not_Found","1"); }
}
#END of FILE Zone:citymist  ID:Not_Found -- #Lord_Rak`Ashiir 

