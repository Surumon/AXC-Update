# Shaman Epic 1.0
# #Neh`Ashiir_ (Shaman Version)
# City of Mist
# True Spirit Faction - Warmly
# Have to save as NPCID Number
# Aramid September 2006

sub EVENT_DEATH {
   quest::faction(342,10);
    quest::ding(); quest::exp(10000);
 }


 # End of File - NPCID 90181 - #Neh`Ashiir_