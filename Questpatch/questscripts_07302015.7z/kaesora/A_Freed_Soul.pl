# on live it is a fire based aoe on death reported to be around 552 pts damage
# exact spell is not specified. using Firebomb, fire based aoe - max damage 499

sub EVENT_DEATH {
  quest::selfcast(6043);
}

# EOF zone: kaesora ID: 88093 npc: A_Freed_Soul

