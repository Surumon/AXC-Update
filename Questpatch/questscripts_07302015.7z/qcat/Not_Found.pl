sub EVENT_SAY{
if($text=~/Hail/i){
quest::say("You do not yet bear the sweet aroma of death and decay that the Plague Bringer bestows upon his most faithful servants. What is it that you seek from Wellis?"); }
}
#END of FILE Zone:qcat  ID:Not_Found -- Wellis_Pestule 

sub EVENT_SAY{
if($text=~/Hail/i){
quest::say("A healthy young Erudite you appear to be. The Plague Bringer has not yet blessed you with his greatest of gifts. What can I do for you young one?"); }
}
#END of FILE Zone:qcat  ID:Not_Found -- Illie_Roln 

sub EVENT_SAY{
if($text=~/Hail/i){
quest::say("The dead are watching you young one. yet you are safe under their otherworldly gaze. Is there something I can do for you?"); }
}
#END of FILE Zone:qcat  ID:Not_Found -- Torin_Krentar 

