sub EVENT_ITEM{
if($itemcount{9270} == 1 && $itemcount{9271} == 1 && $itemcount{9273} == 1 && $itemcount{9272} == 1){
quest::summonitem("9226");
quest::faction("Not_Found","1");
quest::faction("315","1");
quest::faction("Not_Found","1");
quest::faction("Not_Found","1"); }
}
#END of FILE Zone:jaggedpine  ID:Not_Found -- #Randel_Stormwind 

sub EVENT_ITEM{
if($itemcount{8264} == 1){
quest::faction("Not_Found","1");
quest::faction("315","1");
quest::faction("Not_Found","1");
quest::faction("Not_Found","1");
}
if($itemcount{8264} == 3){
quest::faction("Not_Found","1");
quest::faction("315","1");
quest::faction("Not_Found","1");
quest::faction("Not_Found","1"); }
}
#END of FILE Zone:jaggedpine  ID:Not_Found -- #Sergeant_Caelin 

