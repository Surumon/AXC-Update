sub EVENT_AGGRO {
   quest::say("You have trespassed long enough on Sabertooth land!");
}
   
sub EVENT_SPAWN {
      quest::shout("BBBBAAAARRRKKKK!!!!! You humans will pay for ruining our homeland! GRRRRR!! Family Darkpaw of the Sabretooth Clan will slay you all!! BARK!");
}