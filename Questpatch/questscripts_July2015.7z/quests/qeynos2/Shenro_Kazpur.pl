#BeginFile qeynos2\Shenro_Kazpur (2076)
#Quest file for North Qeynos - Shenro Kazpur

sub EVENT_SAY {
  if ($text=~/hail/i) {
    quest::say("Greetings, and welcome to my shop. I am humble merchant Shenro Kazpur of the Silent Fist Clan.");
  }
}

#EndFile qeynos2\Shenro_Kazpur (2076)