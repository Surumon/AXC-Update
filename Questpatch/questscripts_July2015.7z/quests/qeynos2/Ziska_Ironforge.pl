sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to our home of the finest jewelers in all of Norrath."); }
if($text=~/Tayla/i){
quest::say("I know nothing."); }
}
#END of FILE Zone:qeynos2  ID:2060 -- Ziska_Ironforge 

