sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. thirsty traveler!  I recommend trying Crow's special brew.  It's the brew that put Qeynos on the map!"); }
}
#END of FILE Zone:qeynos2  ID:2074 -- Sabnie_Blagard 

