sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings and welcome to Ironforge Weapons! Be sure to purchase Ironforge weapons. they are assured not to break during combat."); }
}
#END of FILE Zone:qeynos2  ID:2062 -- Rendallen_Ironforge 

