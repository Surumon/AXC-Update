sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. $name!  I am Tubal Weaver. humble merchant and retired guardsman of Highkeep.  I make a tidy living dealing with the throngs of adventurers who take it upon themselves to keep Qeynos beetle-free.  If you want some free advice. I recommend that you not deal with any of the merchants in town.  I can offer much lower prices than they because I do not have the overhead of a shop to maintain."); }
}
#END of FILE Zone:qeynos2  ID:2053 -- Tubal_Weaver 

