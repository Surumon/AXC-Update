sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail, $name!  I am sorry but I do not have time to chat, as I must get back to my patrol.  May the Prme Healer walk with you!"); }
}
#END of FILE Zone:qeynos2  ID:2110 -- Guard_Aerryn 

