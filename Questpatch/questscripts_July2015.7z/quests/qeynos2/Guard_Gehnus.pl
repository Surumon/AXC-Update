sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. $name!  Good to see ya!  Welcome to Qeynos!  My name is Gehnus Torris.  If you are looking to do some trading. I would steer clear of that Tubal fellow.  He is from Highpass Hold and they are well known for taking advantage of travelers."); }
}
#END of FILE Zone:qeynos2  ID:2087 -- Guard_Gehnus 

