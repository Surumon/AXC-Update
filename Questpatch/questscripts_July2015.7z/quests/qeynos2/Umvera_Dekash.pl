sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("What. $name?  Do I look like a merchant to you?  Just because all these merchants are in my library. it doesn't mean that I am one.  If you are interested in something other than spell scrolls. then. we can talk."); }
}
#END of FILE Zone:qeynos2  ID:1151 -- Umvera_Dekash 

