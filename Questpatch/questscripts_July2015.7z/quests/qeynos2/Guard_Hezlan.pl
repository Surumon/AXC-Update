sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello. $name.  My name is Hezlan Nur and I am a member of the Qeynos Guard. serving the will of Antonius Bayle.  Anything or anyone trying to get into Qeynos has to go through me. first.  Heh!  I sure love it when those dirty Sabertooths try. though!  Nothing is as gratifying as the death wail of a gnoll."); }
}
#END of FILE Zone:qeynos2  ID:2088 -- Guard_Hezlan 

