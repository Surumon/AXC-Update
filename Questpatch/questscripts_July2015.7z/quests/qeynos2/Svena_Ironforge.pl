sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to Ironforge Jewelers. We are the finest jewelers this side of the Serpent's Spine.");
}
if($text=~/Tayla/i){
quest::say("Tayla is our poor dear sweet half sister. She has runaway to live with those closer to her kind.");
 }
}
#END of FILE Zone:qeynos2  ID:2059 -- Svena_Ironforge 

