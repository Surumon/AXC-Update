sub EVENT_SAY { 
if($text=~/bah/i){
quest::say("You have trespassed long enough on Sabertooth land!"); }
}
#END of FILE Zone:everfrost  ID:30049 -- a_scrawny_gnoll_guard 

