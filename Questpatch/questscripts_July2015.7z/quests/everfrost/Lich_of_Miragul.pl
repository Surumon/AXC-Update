sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Areeeeewwwww"); }
}
#END of FILE Zone:everfrost  ID:3233 -- Lich_of_Miragul 

