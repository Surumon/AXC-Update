sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Brrrrrr!! Grr.. Grreetings. It is freezing out here!!"); }
}
#END of FILE Zone:everfrost  ID:4881 -- Talin_ODonal 

