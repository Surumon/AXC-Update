
sub EVENT_SPAWN
{
quest::emote("'s sleek figure darts towards the pirate, as he starts to try and crawl up the hill, ");
}

sub EVENT_DEATH{
 quest::emote("'s corpse drops to the ground.");
 }