################################
# Ronn_Castekin.pl
# qcat
# Andrew80k
sub EVENT_DEATH{
  quest::say("Argh!.. Mer.. o..na.. it's.. not.. your fault.. arhhh...");
 }

