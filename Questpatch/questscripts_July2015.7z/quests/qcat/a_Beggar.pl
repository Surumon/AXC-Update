sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Guards! Guards! Help me!!");
quest::say("Guards! Guards! Help me!!"); }
}
#END of FILE Zone:qcat  ID:45022 -- a_Beggar 

