#############
#Quest Name: Murder of Hurrietta
#Author: ?? (Update by BWStripes)
#NPC's Involved: 1
#Items involved: 6
#############
###NPC 1
#Name: Garuc_Anehm
#Race 1 (Human), Texture of 3, Size 0, gender of 0
#Location XYZ: -655.0, 357.0, -35.0 in Qeynos Catacombs
#Level: 61
#Type: SK GM
##
#Reward Item: 1-5
#Name: Random Patchwork armor
#ID: 2104, 2106, 2108, 2111, 2112
###
# Item 6
# Name: Rat Shaped Ring
# ID: 13301
# Quest Item
#############
###Item
#Name: Hurrieta's Bloody Dress
#ID: 13134
###
