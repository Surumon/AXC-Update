#Vurag
#Angelox

sub EVENT_COMBAT{
    quest::say("Wha? Why attack Vurag? I do my job!");
}

sub EVENT_DEATH{
 # Flies begin to gather on Vurag's still form.
 }

# EOF zone: dulak
