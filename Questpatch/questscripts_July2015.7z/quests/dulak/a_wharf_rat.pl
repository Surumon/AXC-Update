# NPC: a_wharf_rat
#Angelox

sub EVENT_COMBAT{
    quest::emote("skitters towards you.");
}

sub EVENT_DEATH{
  quest::say("'s corpse squeaks as its bones shatter.");
 }
# EOF zone: dulak