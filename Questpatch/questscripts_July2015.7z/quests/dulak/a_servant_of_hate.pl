# NPC: a_servant_of_hate
#Angelox

sub EVENT_COMBAT{
    quest::emote("lunges at you with reckless abandon.");
}

sub EVENT_DEATH{
  quest::emote("'s corpse utters one final curse before expiring.");
 }

# EOF zone: dulak