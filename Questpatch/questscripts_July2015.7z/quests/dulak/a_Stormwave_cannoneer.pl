# NPC: a_Stormwave_cannoneer
#Angelox

sub EVENT_DEATH{
  quest::emote("My death should have come at sea!");
 }

# EOF zone: dulak