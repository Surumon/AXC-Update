# NPC: #Konus_Alatuk
#Angelox

sub EVENT_COMBAT{
    quest:emote("separates from the shadows, dagger in hand.");
}

sub EVENT_DEATH{
    quest::emote("'s corpse hisses through clenched teeth, 'You are lucky!'");
 }

# EOF zone: dulak