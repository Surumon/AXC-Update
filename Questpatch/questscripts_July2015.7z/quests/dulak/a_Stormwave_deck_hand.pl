# NPC: a_Stormwave_crew_member
#Angelox

sub EVENT_DEATH{
  quest::emote("falls to one knee before sinking entirely to the ground.");
 }

# EOF zone: dulak