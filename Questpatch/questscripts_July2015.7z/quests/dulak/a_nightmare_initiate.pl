# NPC: a_blackblooded_nightmare
#Angelox

sub EVENT_COMBAT{
    quest::say("Feel the wrath of Innoruuk!");
}

sub EVENT_DEATH{
  quest::emote("clutches his chest and collapses to the ground");
 }

# EOF zone: dulak