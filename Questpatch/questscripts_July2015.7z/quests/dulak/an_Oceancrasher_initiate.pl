# NPC: an_Oceancrasher_initiate
#Angelox

sub EVENT_COMBAT{
    quest::say("Come on then, it has been awhile since a body hung from the rigging!");
}

sub EVENT_DEATH{
  quest::say("All debts are paid in the end.");
 }

# EOF zone: dulak