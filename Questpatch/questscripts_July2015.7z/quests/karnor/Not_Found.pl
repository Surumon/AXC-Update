sub EVENT_DEATH{
quest::summonitem("12979");	
}
#END of FILE Zone:karnor  ID:Not_Found -- Drolvarg 

