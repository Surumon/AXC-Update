sub EVENT_DEATH { 
   quest::setglobal("poeb_warlord",1,3,"D4");
} 
