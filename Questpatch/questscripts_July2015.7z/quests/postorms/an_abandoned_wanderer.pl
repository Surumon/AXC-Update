sub EVENT_SAY{
if($text=~/Hail/i){
quest::say("The dreams, they come and go, but they're always the same. The eternal storm amidst the Storms; what could it mean? If only I could find out, I might be able to rest peacefully at night."); }
}
#END of FILE Zone:postorms  ID:Not_Found -- an_abandoned_wanderer 