sub EVENT_SIGNAL {
  #Check if any tempest toads still alive (210047)
  #If none alive, spawn Drornok_Tok_Vo`Lok (210239) at -80,-190,-425,140 and despawn myself
}