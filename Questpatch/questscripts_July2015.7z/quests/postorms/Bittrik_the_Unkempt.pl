sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Oh me oh my! A visitor! Pardon me for not cleaning up. but I wasn't expecting company so early! Bittrik's the name. stories are my game. Looking to unmask the secret of the Kingdom of Lok? I might indeed have that story tucked away somewhere. Perhaps you'd fancy a smaller story. one revolving around an ill-tempered giant? That one happens to be one of my favorites! Of course. there are the stories of raging Storms to be found through this land. which I know plenty about as well. So. what'll it be. friend?"); }
}
#END of FILE Zone:postorms  ID:210057 -- Bittrik_the_Unkempt 

