sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("does not move his eyes from the blazing fire in front of him. As you watch. you can see the flickering. glowing embers light up his face; the blaze jumps and snaps in his eyes. a sign that Krelk yearns for days long gone. You watch him for what seems like an eternity before you finally snap out of the daze and notice that he took no heed to your presence. It appears he is far too engulfed in the flame to respond."); }
}
#END of FILE Zone:postorms  ID:210049 -- Krelk_the_Drifter 

