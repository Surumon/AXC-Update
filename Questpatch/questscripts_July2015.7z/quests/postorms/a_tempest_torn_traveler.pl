sub EVENT_SAY{
if($text=~/Hail/i){
quest::say("Well hello there, cutie! It's so rare now days to see someone as strong and handsome as you around these parts. Most of the strangers that wash ashore stay in these caves and aren't much of a sight to look at. But you, you're different, and I like that. Take care of yourself, stranger."); }
}
#END of FILE Zone:postorms  ID:Not_Found -- a_tempest_torn_traveler 