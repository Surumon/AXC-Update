sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Wut yu want?"); }
}
#END of FILE Zone:postorms  ID:210048 -- a_forgotten_traveler 

