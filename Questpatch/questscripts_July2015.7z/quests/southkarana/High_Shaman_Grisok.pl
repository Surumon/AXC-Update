sub EVENT_DEATH { 
quest::summonitem("13167");	
}
#END of FILE Zone:southkarana  ID:2558 -- High_Shaman_Grisok 

