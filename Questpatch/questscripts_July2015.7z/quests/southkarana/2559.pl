sub EVENT_DEATH { 
quest::summonitem("13166");	
}
#END of FILE Zone:southkarana  ID:2559 -- High_Shaman_Phido 

