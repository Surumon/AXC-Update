sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Follow path of life. Rodcet Nife is only true way."); }
}
#END of FILE Zone:southkarana  ID:14048 -- Brother_Drash 

