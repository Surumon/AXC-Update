sub EVENT_DEATH { 
quest::summonitem("13165");	
}
#END of FILE Zone:southkarana  ID:1673 -- Ghanex_Drah 

