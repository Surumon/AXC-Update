sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to my field of decay. Won't you be so kind as to attack me? I have need of more bodies to join my diseased legion. Try it. maybe you shall win and gain my trusty [Pestilence].");
}
if($text=~/pestilence/i){
quest::say("My beloved scythe. Upon my death. my soul shall live withn her.  Such is the pact."); }
}
#END of FILE Zone:southkarana  ID:3312 -- Lord_Grimrot 

