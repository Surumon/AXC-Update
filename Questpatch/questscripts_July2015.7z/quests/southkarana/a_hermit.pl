sub EVENT_SAY { 
if($text=~/better/i){
quest::say("Ha!! Fertilizer for the forests and another notch in the belt of the Unkempt Druids!"); }
}
#END of FILE Zone:southkarana  ID:14064 -- a_hermit 

