sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail!  I am the jail clerk of Highkeep.  How may I be of service?"); }
}
#END of FILE Zone:highkeep  ID:6058 -- Jail_Clerk_Maryl 

