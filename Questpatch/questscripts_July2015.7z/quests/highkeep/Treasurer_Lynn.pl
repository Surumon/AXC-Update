sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings!!  Welcome to Highkeep. home of the greatest casino in all of Norrath.  Please visit our fine casino on the second floor."); }
}
#END of FILE Zone:highkeep  ID:6077 -- Treasurer_Lynn 

