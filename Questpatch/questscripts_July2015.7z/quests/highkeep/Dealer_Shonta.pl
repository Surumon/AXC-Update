sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name! I am sorry but this table has a hundred platinum minimum. Maybe you should start on the copper tables."); }
}
#END of FILE Zone:highkeep  ID:6064 -- Dealer_Shonta 

