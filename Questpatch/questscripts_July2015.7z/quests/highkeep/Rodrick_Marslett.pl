sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Oooh.. Hello. [guard]. Please do not let the [Teir'Dal] at me again. I can take no more."); }
}
#END of FILE Zone:highkeep  ID:6056 -- Rodrick_Marslett 

