sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello. How nice to meet you. $name!"); }
}
#END of FILE Zone:highkeep  ID:6082 -- Isabella_Cellus 

