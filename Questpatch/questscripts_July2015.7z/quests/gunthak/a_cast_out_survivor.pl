# NPC:a_cast_out_survivor (224037)
# Angelox

#sub EVENT_COMBAT{
 #   quest::say("I always enjoy getting a good kill in before breakfast.");
#}

sub EVENT_DEATH{
  quest::emote("'s corpse appears amazed at this turn of events.");
 }

# EOF zone: Gunthak