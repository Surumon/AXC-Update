# NPC:#Dreadmaster_Jrup
# Angelox

sub EVENT_COMBAT{
    quest::emote("hisses and draws back. 'It is your misfortune to meet me. It is my pleasure meet you!'");
}

sub EVENT_DEATH{
  quest::emote("My Lord Innoruuk, I do not understand.");
 }

# EOF zone: Gunthak