# NPC:a_pestilent_troll_zombie
# Angelox

#sub EVENT_COMBAT{
 #   quest::say("I always enjoy getting a good kill in before breakfast.");
#}

sub EVENT_DEATH{
  quest::emote("'s corpse sinks into a stinking pile of refuse.");
 }

# EOF zone: Gunthak