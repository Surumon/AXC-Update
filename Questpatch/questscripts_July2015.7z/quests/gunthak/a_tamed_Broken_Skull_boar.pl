# NPC:a_tamed_Broken_Skull_boar
# Angelox

sub EVENT_COMBAT{
    quest::emote("claws at their throat.");
}

sub EVENT_DEATH{
  quest::emote("r's corpse emits a foul odor and lies still.");
 }

# EOF zone: Gunthak