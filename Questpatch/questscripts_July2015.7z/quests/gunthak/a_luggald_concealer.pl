#npc - assorted death text
#zone - Gunthak
#by Angelox

sub EVENT_DEATH {
    quest::say("I shall be avenged!");
 }