sub EVENT_DEATH{
quest::summonitem("12980");	
}
#END of FILE Zone:chardok  ID:Not_Found -- Iksar 

