sub EVENT_SIGNAL {
if ($signal == 1){
quest::addloot(67030,1);

}
 }